
package com.harishfysx.bpm.jaxws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name = "searchClientResponse", namespace = "http://bpm.harishfysx.com/")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "searchClientResponse", namespace = "http://bpm.harishfysx.com/")
public class SearchClientResponse {

    @XmlElement(name = "return", namespace = "")
    private com.harishfysx.bpm.Member _return;

    /**
     * 
     * @return
     *     returns Member
     */
    public com.harishfysx.bpm.Member getReturn() {
        return this._return;
    }

    /**
     * 
     * @param _return
     *     the value for the _return property
     */
    public void setReturn(com.harishfysx.bpm.Member _return) {
        this._return = _return;
    }

}
