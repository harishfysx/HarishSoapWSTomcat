package com.harishfysx.bpm;

import javax.jws.WebService;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

@WebService(endpointInterface="com.harishfysx.bpm.SearchMember",
portName="SearchMemberPort",
serviceName="SearchMemberService")

public class SearchMemberImp implements SearchMember {
    
    Member patientObj=new Member();
	
	@Override
	public Member searchClient(String memberID) {
		// TODO Auto-generated method stub
		
		Connection connection = null;
		String schema_name= "";
        try {
            try {
				connection = DBConnection.getConnection();
				schema_name= DBConnection.getSchema();
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
 
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally{
            if(connection!=null){
                System.out.println("Connected successfully.");
             
               
                try {
                	String sql = "SELECT * FROM "+schema_name+".MEMBERS WHERE MEMBERID="+memberID;
                	 
                	Statement statement = connection.createStatement();
                	ResultSet results = statement.executeQuery(sql);
     
					System.out.println(memberID);
					System.out.println(connection);
					System.out.println(results.getFetchSize());
					if (!results.next() ) {
					    System.out.println("no data");
					    
					    patientObj.setFirstName("NOT FOUND");
						patientObj.setLastName("NOT FOUND");
						patientObj.setMemberID("NOT FOUND");
						patientObj.setDob(new Date());
						patientObj.setExpiryDate(new Date());
						patientObj.setOrganization("NOT FOUND");
						patientObj.setPlanName("NOT FOUND");
						
					} else {

					    do {
					    	String data = results.getString(1);
							  
							  System.out.println("printing data:"+data);

							  System.out.println("Fetching data by column index for row " + results.getRow() + " : " + data);


							  // Get the data from the current row using the column name - column data are in the VARCHAR format

							  String  firstName = results.getString("FIRSTNAME");
							  String  lastName = results.getString("LASTNAME");
							  Date 	dateOfBirth  = results.getDate("DOB");
							  String  id = results.getString("MEMBERID");
							  Date 	expiryDate  = results.getDate("EXPIRY");
							  String  organization = results.getString("ORGANIZATION");
							  String  planName = results.getString("PLAN");
							  
							  
							    patientObj.setFirstName(firstName);
								patientObj.setLastName(lastName);
								patientObj.setMemberID(id);
								patientObj.setDob(dateOfBirth);
								patientObj.setExpiryDate(expiryDate);
								patientObj.setOrganization(organization);
								patientObj.setPlanName(planName);

							  System.out.println("First Name " + results.getRow() + " : " + firstName);
							  System.out.println("Last Name " + results.getRow() + " : " + lastName);
							  System.out.println("expiry " + results.getRow() + " : " + expiryDate);
							  System.out.println("Id " + results.getRow() + " : " + id);

					    } while (results.next());
					} 
					
					
					
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
		
		
		
        return patientObj;
	}

}
