package com.harishfysx.bpm;

import javax.jws.WebService;

@WebService
public interface SearchMember {
	
	
	Member searchClient(String memberID);

}
