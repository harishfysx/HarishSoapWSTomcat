package com.harishfysx.bpm;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;




/**
 * @author Chandan Singh
 */
public class DBConnection
{
	//Get connection
	public static Connection getConnection() throws SQLException, ClassNotFoundException, NamingException
	{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource)ctx.lookup("java:comp/env/jdbc/CHARAKA");
		Connection connection = ds.getConnection();
                System.out.println(connection);

		return connection;
	}
	
	//get schema 
	
	public static String getSchema() throws SQLException, ClassNotFoundException, NamingException
	{
		// Get a handle to the JNDI environment naming context
		Context env = (Context)new InitialContext().lookup("java:comp/env");

		// Get a single value
		String schema_name = (String)env.lookup("schema_name");


		return schema_name;
	}
}
